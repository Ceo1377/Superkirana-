// Example script
document.addEventListener('DOMContentLoaded', () => {
    console.log('Superkirana homepage loaded successfully');
});
